<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div style="position: relative; ">
        <div style="padding-left: 120px;">
            <img src="img/Salinasicon.png" height="120" />
            <img src="img/logo-salinas-resort.png" height="120" />
        </div>
        
        
        <div style="position: absolute; bottom: 8px; right: 150px;">
            <img src="img/redes.png" style="width: 100%;height: auto;"/>
        </div>
    </div>

    <table style="padding-left: 100px; padding-right: 100px;" >
    
        <tr>

            <td></td>
        </tr>
        <tr>
            <td style="font-size: 20px; display: inline-block ; text-align: justify;">
                <h1 style="background-color: #aaaaaa ;">Carta de autorização para utilização de terceiros</h1><br>
            Eu,_______________________________________, inscrito no CPF:_________________________,
            e no RG:____________________________, proprietário da unidade:________________________________,
            cota:__________________________, Autorizo o Sr(a):________________________________,
            inscrito no CPF:_________________________, e no RG:______________________, 
            endereço:______________________________________________, CEP:_______________________, Telefone(___)__________________
            e-mail:_____________________________, de minha semana no período de ____/____/____ a ____/____/____, com os seguintes acompanhantes.<br>
            <br>(___)Apartamento 1 quarto - acomodação máxima(4 pessoas), <br>(___)Apartamento 2 quartos - acomodação máxima(7 pessoas).<br>        
            <br>Acompanhante(1)____________________________________________________________idade:_______.
            <br>inscrito no CPF:_______________________________.<br>
            <br>Acompanhante(2)____________________________________________________________idade:_______.
            <br>inscrito no CPF:_______________________________.<br>
            <br>Acompanhante(3)____________________________________________________________idade:_______.
            <br>inscrito no CPF:_______________________________.<br>
            <br>Acompanhante(4)____________________________________________________________idade:_______.
            <br>inscrito no CPF:_______________________________.<br>
            <br>Acompanhante(5)____________________________________________________________idade:_______.
            <br>inscrito no CPF:_______________________________.<br>
            <br>Acompanhante(6)____________________________________________________________idade:_______.
            <br>inscrito no CPF:_______________________________.<br><br>
            <br>
            Estou ciente e me responsabilizo por qualquer dano material no periodo de locação indicado por mim neste formulário. 
            Assinatura reconhecida em cartório ou envio da carta devidamente preenchida junto a um documento com foto do proprietário.
                <br>
                <br>
            <br>
            <div style="width: 100%;">
                <center>
                    ___________________________________________________________________
                    <h2>Assinatura do(a) Proprietário(a)</h2><br>
                    _____________________________,______de______________de______.
                </center>
            </div>
        </tr>
    </table>
<br>
<br>
    <div style="position: relative;">
       
        <div style="position: absolute;left: 150px;">
            <img src="img/GFPhoteis.png" />
        </div>
        <div style="position: absolute;right: 150px;">
            <img src="img/End-footer.png" style="width: 100%;height: auto;"/>
        </div>
    </div>
</body>
</html>